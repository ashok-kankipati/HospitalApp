# Gather chat

A responsive chat app for a small group, built for PythonAnywhere free hosting.

- **Frontend:** HTML, CSS, vanilla JavaScript; mobile conversation menu, public rooms, private conversations, earlier-message loading.
- **Backend:** Flask JSON API with session authentication, hashed passwords, CSRF protection, input validation, and database-backed request limits.
- **Database:** SQLite using Python's built-in sqlite3; automatically initialized on startup. Parameterized queries and indexed message history.
- **Updates:** short HTTP polling every 3 seconds while the tab is visible; conversation list refreshes about every 15 seconds. No Node build, Redis, background worker, or WebSocket service needed.

## Run locally

Use Python 3.10 or newer. From the project directory:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python app.py
```

Open http://127.0.0.1:5000. Create an administrator with `flask --app app create-admin`, sign in, and use **Create account** to add users. Sign in with two accounts in separate browser profiles or a private window to test conversations. Click the plus next to Direct Messages and enter the other account's username. Public rooms are readable by every signed-in user.

On macOS/Linux, use `.venv/bin/python` instead of `.venv\Scripts\python`.

## Deploy on PythonAnywhere free

1. Create a free PythonAnywhere account. Upload the project into `/home/YOUR_USERNAME/chatingApp` using the Files tab or clone your own repository in a Bash console. Upload `app.py`, `wsgi.py`, `requirements.txt`, and the entire `chat` directory. Do not upload your local `.venv` or `instance` directory.
2. In a PythonAnywhere **Bash console**, run:

   ```bash
   cd /home/YOUR_USERNAME/chatingApp
   mkvirtualenv --python=/usr/bin/python3.13 gather-env
   pip install -r requirements.txt
   ```

   Choose an available Python version if 3.13 is not offered; use that same version in the next step.
3. In **Web → Add a new web app**, choose the free domain, **Manual configuration**, and the matching Python version.
4. Set **Source code** and **Working directory** to `/home/YOUR_USERNAME/chatingApp`. Set **Virtualenv** to `/home/YOUR_USERNAME/.virtualenvs/gather-env`.
5. Open the WSGI configuration file linked in the Web tab. Replace its contents with:

   ```python
   import sys
   project = '/home/YOUR_USERNAME/chatingApp'
   if project not in sys.path:
       sys.path.insert(0, project)
   from wsgi import application
   ```

6. Add a static mapping: URL `/static/` → directory `/home/YOUR_USERNAME/chatingApp/chat/static`. Do not expose `instance` as a static directory.
7. Enable **Force HTTPS** in the Web tab. The supplied `wsgi.py` enables secure session cookies, which require HTTPS.
8. Click **Reload** and open `https://YOUR_USERNAME.pythonanywhere.com`. Create your administrator using the console command below, then sign in. If there is an error, inspect the error log linked in the Web tab.

The database and random signing key are created in `instance/` automatically. Keep this directory during code updates. Optionally set a stable `SECRET_KEY` environment variable in your WSGI configuration before importing the application; otherwise the generated key persists on disk. Never share the signing key.

PythonAnywhere currently lists 512 MiB storage, one web worker, and a one-month expiry for free web apps. Check the Web tab and renew before expiry. SQLite is available to everyone; new free accounts do not receive MySQL. This setup is intended for small groups and light traffic. Polling, message storage, and password hashing consume hosting resources. It has no attachments, email password recovery, moderation dashboard, or end-to-end encryption. Private-message access is enforced by the server; the hosting/database owner can access stored messages.

Deployment references: [Flask setup](https://help.pythonanywhere.com/pages/Flask), [database availability](https://help.pythonanywhere.com/pages/KindsOfDatabases), [free account limits](https://help.pythonanywhere.com/pages/FreeAccountsFeatures).

## Session privacy

Each page uses a random key held only in memory to select its server-side session, plus a separate authentication token. Different tabs can sign in as different users without sharing their session. Logout affects only the current tab. Inactive server session records are removed after 24 hours. Closing, refreshing, or opening a new tab requires sign-in, even if cookies are restored. Logout clears the session. Stale CSRF tokens recover automatically while the authenticated page remains open. Mobile browsers may suspend and restore a live tab when the app is backgrounded; this is not reliably distinguishable from closing the browser app. Online status has a separate two-minute timeout.

## Data and maintenance

Back up the database regularly from a PythonAnywhere Bash console using SQLite's backup API:

```bash
cd /home/YOUR_USERNAME/chatingApp
python -c "import sqlite3; source=sqlite3.connect('instance/chat.sqlite3'); backup=sqlite3.connect('instance/chat-backup.sqlite3'); source.backup(backup); backup.close(); source.close()"
```

Download the backup to private storage and retain `instance/secret.key` securely. Messages expire for everyone five minutes after the first other user sees them in a focused, visible conversation. Unread messages remain. Expired rows are deleted on the next server request; no background worker is needed. Existing backups may retain messages. Monitor storage usage. Rate limits are stored in SQLite; authentication uses the WSGI remote address, so users sharing an address may share the login limit.

## Verify

```bash
python -m unittest discover -s tests -v
```

Tests cover account sessions, CSRF, message validation, public history cursors, private conversation authorization, and message throttling.

Project layout: `chat/db.py` owns persistence, `chat/routes.py` owns API behavior, `chat/__init__.py` configures security and startup, `chat/templates` and `chat/static` contain the frontend. `app.py` is the local entry point; `wsgi.py` is the hosting entry point.

The Clear chat button in the conversation header asks for confirmation, then permanently deletes that conversation?s messages for everyone. Any signed-in user can clear a public room; either participant can clear a private conversation. Other conversations are unaffected.


## Administrator password resets

After uploading the updated code, create a dedicated administrator from the PythonAnywhere Bash console:

```bash
workon gather-env
cd ~/chatingApp
flask --app app create-admin
```

Enter a new username and a strong password at the hidden prompts. There is no default admin password and existing accounts cannot be claimed by this command. Reload the web app and sign in normally as the administrator. The header shows Reset password. Enter the regular user's username, their new password, and your own administrator password. Verify the person's identity and share the replacement privately. Resetting invalidates all their existing sessions. This panel cannot reset other administrator accounts.

The login form requests autocomplete off, but browser password managers may ignore it. In Chrome, open Google Password Manager > Settings and disable Offer to save passwords and passkeys to stop browser save prompts.


## Presence, accounts, and replies

Only administrators can create chat accounts using **Create account** in the header. Public registration is disabled. Existing accounts remain usable.

The People list shows Online or a local last-seen date and time; private conversations also show this in the header. Visible pages send a heartbeat every three seconds. After 2 minutes without a heartbeat (closed page, hidden tab, or lost connection), the user appears offline. Signing out removes that session immediately; another active session keeps the user online.

Tap a message or its Reply button, type your reply, then send. Cancel reply clears the selection. Replies quote the original message while it exists; after deletion or expiry, they show Original message unavailable. Database columns and the presence table are added automatically on startup.


Administrators can use **Remove user**, select an existing regular account, enter their administrator password, and confirm. Removal disables login and all existing sessions, and hides the user from presence. Existing history remains until normal expiry; usernames stay reserved. Administrator accounts cannot be removed through this panel.


Administrator accounts are excluded from online and last-seen lists. Administrators can use **Create personal chat** to choose exactly two regular users. The private conversation appears for both users and opens by default at their next sign-in; users already signed in see it in Direct Messages after the conversation list refreshes. They can select any other accessible room. Creating another personal chat for a user replaces their default; existing conversations remain. The administrator who sets up the chat does not gain access to it.


On phones, the chat header shows the conversation name and presence. The three-dot Chat options menu contains avatar, admin actions, clear chat, and logout. Use the conversation menu to open the sidebar; tap outside it to return to chat. The compact composer keeps the send button alongside the message field.


## Photo messages

Use Photo beside Send to take a camera picture or select one from gallery/files. Preview it, add an optional caption, and send it as its own message. Desktop uses a permission-based webcam; mobile requests the native camera picker. The browser compresses photos before upload; Pillow validates and normalizes them on the server. Photos use authenticated access and are deleted with their message. See DEPLOY_PYTHONANYWHERE.md for update instructions and format/size limits. Install the updated requirements before reloading your deployment.


## Voice calls

Open a private chat with an online person and press Call. Incoming calls show Accept/Decline; active calls have Mute and End call. Audio is browser-to-browser via WebRTC and is not recorded. HTTPS and microphone permission are required. HTTP polling coordinates calls on the free PythonAnywhere WSGI setup. An external TURN relay may be required for mobile/restricted networks; see DEPLOY_PYTHONANYWHERE.md for configuration and limitations.
