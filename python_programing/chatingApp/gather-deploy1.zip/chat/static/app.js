const $ = id => document.getElementById(id);
const avatars = { fox: '🦊', cat: '🐱', dog: '🐶', panda: '🐼', koala: '🐨', lion: '🦁', rabbit: '🐰', bear: '🐻', owl: '🦉', penguin: '🐧', frog: '🐸', unicorn: '🦄' };
const avatarIcon = key => avatars[key] || avatars.fox;
let browserToken = '';
let csrf = '', user = null, registering = false, rooms = [], active = null, last = 0, first = 0;
let generation = 0, timer, dialogMode = 'room', polling = false, roomPoll = 0;
async function api(path, options = {}) {
  const response = await fetch('/api' + path, { ...options, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf, 'X-Browser-Token': browserToken }, credentials: 'same-origin' });
  const body = await response.json();
  if (!response.ok) {
    if (response.status === 401 && user) { user = null; clearTimeout(timer); $('app').hidden = true; $('auth').hidden = false; $('username').value = ''; $('password').value = ''; browserToken = ''; }
    throw new Error(body.error || 'Something went wrong. Please try again.');
  }
  return body;
}
const post = (path, body) => api(path, { method: 'POST', body: JSON.stringify(body) });
function element(tag, className, text) { const node = document.createElement(tag); node.className = className; if (text !== undefined) node.textContent = text; return node; }
async function refreshRooms() {
  rooms = (await api('/rooms')).rooms;
  $('room-list').replaceChildren(); $('direct-list').replaceChildren();
  rooms.forEach(room => {
    const button = element('button', active?.id === room.id ? 'active' : '');
    button.append(element('span', '', room.private ? '◉' : '#'), document.createTextNode(room.name));
    button.onclick = () => selectRoom(room);
    $(room.private ? 'direct-list' : 'room-list').append(button);
  });
}
function addMessages(messages, prepend = false) {
  const fragment = document.createDocumentFragment();
  messages.forEach(message => {
    if ($('messages').querySelector(`[data-id="${message.id}"]`)) return;
    const row = element('article', 'message-row' + (message.user_id === user.id ? ' mine' : ''));
    row.dataset.id = message.id; row.dataset.sender = message.user_id;
    const content = element('div', 'message-content');
    const meta = element('div', 'message-meta');
    const date = new Date(message.created_at);
    const time = element('time', '', date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    time.dateTime = message.created_at; time.title = date.toLocaleString();
    meta.append(time);
    if (message.user_id === user.id) {
      const receipt = element('span', 'message-receipt', '✓ Sent');
      receipt.setAttribute('aria-label', 'Sent; not seen yet');
      meta.append(receipt);
    }
    content.append(element('div', 'bubble', message.body), meta);
    const avatar = element('span', 'avatar', avatarIcon(message.avatar));
    avatar.setAttribute('role', 'img');
    avatar.setAttribute('aria-label', message.username + ' avatar');
    row.append(avatar, content);
    fragment.append(row);
    last = Math.max(last, message.id); first = first ? Math.min(first, message.id) : message.id;
  });
  if (prepend) $('messages').prepend(fragment); else $('messages').append(fragment);
}
async function selectRoom(room) {
  active = room; const version = ++generation; last = 0; first = 0;
  $('app').classList.remove('show-sidebar'); $('messages').replaceChildren(); $('older').hidden = true;
  $('chat-error').textContent = ''; $('room-title').textContent = room.name;
  $('room-icon').textContent = room.private ? '◉' : '#';
  $('room-description').textContent = room.private ? 'A private conversation between the two of you.' : 'A public room. Everyone can read and join in.';
  $('welcome-title').textContent = room.private ? `Your conversation with ${room.name}` : `Welcome to #${room.name}`;
  for (const nav of [$('room-list'), $('direct-list')]) for (const button of nav.children) button.classList.toggle('active', button.textContent.slice(1) === room.name && (nav.id === 'direct-list') === Boolean(room.private));
  try {
    const result = await api(`/rooms/${room.id}/messages`);
    if (version !== generation) return;
    addMessages(result.messages); applyExpirations(result); $('older').hidden = result.messages.length < 100;
    $('message-scroll').scrollTop = $('message-scroll').scrollHeight;
    $('connection').textContent = '● Connected';
  } catch (error) { if (version === generation) $('chat-error').textContent = error.message; }
}
async function poll() {
  if (polling || !user) return;
  polling = true;
  try {
    if (!document.hidden && active) {
      const version = generation;
      const result = await api(`/rooms/${active.id}/messages?after=${last}`);
      if (version === generation) {
        const scroll = $('message-scroll'); const nearBottom = scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 120;
        addMessages(result.messages); applyExpirations(result); if (nearBottom) scroll.scrollTop = scroll.scrollHeight;
        $('connection').textContent = '● Connected';
      }
      if (++roomPoll % 5 === 0) await refreshRooms();
    }
  } catch (error) { $('connection').textContent = 'Reconnecting…'; }
  finally { polling = false; if (user) timer = setTimeout(poll, document.hidden ? 15000 : 3000); }
}
async function enterApp() {
  $('admin-reset').hidden = !user.is_admin;
  $('auth').hidden = true; $('app').hidden = false; $('my-name').textContent = user.username; $('my-avatar').textContent = avatarIcon(user.avatar);
  $('selected-avatar-icon').textContent = avatarIcon(user.avatar);
  await refreshRooms(); await selectRoom(rooms[0]); clearTimeout(timer); timer = setTimeout(poll, 3000);
}
$('auth-toggle').onclick = () => {
  registering = !registering; $('auth-title').textContent = registering ? 'Find your people.' : 'Welcome back.';
  $('auth-description').textContent = registering ? 'Create an account to join the conversation.' : 'Sign in and pick up the conversation.';
  $('auth-submit').textContent = registering ? 'Create account ↗' : 'Sign in ↗';
  $('auth-toggle').textContent = registering ? 'Already have an account? Sign in' : 'New here? Create an account';
  $('password').autocomplete = 'off'; $('auth-error').textContent = '';
};
$('auth-form').onsubmit = async event => {
  event.preventDefault(); $('auth-submit').disabled = true; $('auth-error').textContent = '';
  try { const result = await post(registering ? '/register' : '/login', { username: $('username').value, password: $('password').value }); csrf = result.csrf; browserToken = result.browser_token; user = result.user; $('password').value = ''; await enterApp(); }
  catch (error) { $(user ? 'chat-error' : 'auth-error').textContent = error.message; }
  finally { $('auth-submit').disabled = false; }
};
$('chat-logout').onclick = $('logout').onclick = async () => {
  $('chat-logout').disabled = true; $('logout').disabled = true;
  try { await post('/logout', {}); user = null; generation++; clearTimeout(timer); $('app').hidden = true; $('auth').hidden = false; $('username').value = ''; $('password').value = ''; browserToken = ''; csrf = (await api('/session')).csrf; }
  catch (error) { $('chat-error').textContent = error.message; }
  finally { $('chat-logout').disabled = false; $('logout').disabled = false; }
};
$('composer').onsubmit = async event => {
  event.preventDefault(); const text = $('message').value.trim(); if (!text || !active || $('send').disabled) return;
  const roomId = active.id; const draft = $('message').value; $('send').disabled = true; $('chat-error').textContent = '';
  try { await post(`/rooms/${roomId}/messages`, { body: text }); if ($('message').value === draft) { $('message').value = ''; $('character-count').textContent = '0 / 2000'; } clearTimeout(timer); await poll(); }
  catch (error) { $('chat-error').textContent = error.message; }
  finally { $('send').disabled = false; $('message').focus(); }
};
$('message').onkeydown = event => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); $('composer').requestSubmit(); } };
$('message').oninput = () => $('character-count').textContent = `${$('message').value.length} / 2000`;
$('older').onclick = async () => {
  const version = generation; $('older').disabled = true;
  try { const result = await api(`/rooms/${active.id}/messages?before=${first}`); if (version !== generation) return; const scroll = $('message-scroll'); const oldHeight = scroll.scrollHeight; addMessages(result.messages, true); applyExpirations(result); scroll.scrollTop += scroll.scrollHeight - oldHeight; $('older').hidden = result.messages.length < 100; }
  catch (error) { $('chat-error').textContent = error.message; } finally { $('older').disabled = false; }
};
function openDialog(mode) {
  dialogMode = mode; $('dialog-title').textContent = mode === 'room' ? 'Create a room' : 'Start a conversation';
  $('dialog-description').textContent = mode === 'room' ? 'Public rooms are visible to everyone. Give yours a name.' : 'Enter the exact username of someone who has signed up.';
  $('dialog-label').textContent = mode === 'room' ? 'Room name' : 'Username'; $('dialog-input').value = ''; $('dialog-error').textContent = ''; $('create-dialog').showModal();
}
$('new-room').onclick = () => openDialog('room'); $('new-direct').onclick = () => openDialog('direct');
$('close-dialog').onclick = () => $('create-dialog').close();
$('create-form').onsubmit = async event => {
  event.preventDefault(); const button = event.submitter; button.disabled = true;
  try { const value = $('dialog-input').value; const result = await post(dialogMode === 'room' ? '/rooms' : '/direct', dialogMode === 'room' ? { name: value } : { username: value }); await refreshRooms(); $('create-dialog').close(); await selectRoom(rooms.find(room => room.id === result.id)); }
  catch (error) { $('dialog-error').textContent = error.message; } finally { button.disabled = false; }
};
$('menu').onclick = () => $('app').classList.toggle('show-sidebar');
async function boot() { try { const result = await api('/session'); csrf = result.csrf; user = result.user; if (user) await enterApp(); } catch (error) { $(user ? 'chat-error' : 'auth-error').textContent = 'Unable to connect. Refresh to retry. ' + error.message; } }
boot();

function applyExpirations(result) {
  for (const expiry of result.expirations || []) {
    const row = $('messages').querySelector(`[data-id="${expiry.id}"]`);
    if (row) {
      row.dataset.expires = Date.now() + Math.max(0, expiry.expires_at - result.server_time) * 1000;
      const receipt = row.querySelector('.message-receipt');
      if (receipt) {
        receipt.textContent = '✓✓ Seen';
        receipt.classList.add('is-seen');
        receipt.setAttribute('aria-label', 'Seen by another person');
        receipt.title = 'Seen by another person. Deletes 5 minutes after first seen.';
      }
    }
  }
}
let reading = false;
setInterval(async () => {
  for (const row of $('messages').children) {
    if (row.dataset.expires && Number(row.dataset.expires) <= Date.now()) row.remove();
  }
  if (!user || !active || document.hidden || !document.hasFocus() || reading) return;
  const bounds = $('message-scroll').getBoundingClientRect();
  const visible = [...$('messages').children].filter(row => {
    const rect = row.getBoundingClientRect();
    return Number(row.dataset.sender) !== user.id && !row.dataset.seen && rect.bottom > bounds.top && rect.top < bounds.bottom;
  }).slice(0, 100);
  if (!visible.length) return;
  reading = true;
  try {
    await post(`/rooms/${active.id}/seen`, { ids: visible.map(row => Number(row.dataset.id)) });
    visible.forEach(row => { row.dataset.seen = '1'; if (!row.dataset.expires) row.dataset.expires = Date.now() + 300000; });
  } catch (_) { /* Retry visible receipts on the next tick. */ }
  finally { reading = false; }
}, 1000);
window.addEventListener('pageshow', event => {
  $('username').value = ''; $('password').value = '';
  if (event.persisted) location.reload();
});

let syncing = false;
setInterval(async () => {
  if (!user || !active || document.hidden || syncing) return;
  syncing = true;
  const version = generation, roomId = active.id;
  const rows = [...$('messages').children];
  try {
    for (let i = 0; i < rows.length; i += 100) {
      const batch = rows.slice(i, i + 100);
      const result = await post(`/rooms/${roomId}/state`, { ids: batch.map(row => Number(row.dataset.id)) });
      if (version !== generation) return;
      batch.forEach(row => { if (!result.alive.includes(Number(row.dataset.id))) row.remove(); });
      applyExpirations(result);
    }
  } catch (_) { /* Reconcile again when the connection returns. */ }
  finally { syncing = false; }
}, 3000);

$('clear-chat').onclick = async () => {
  if (!active || !user) return;
  const room = active;
  if (!window.confirm(`Clear all messages in ${room.name}? This permanently deletes the chat history for everyone in this conversation and cannot be undone.`)) return;
  $('clear-chat').disabled = true;
  $('chat-error').textContent = '';
  try {
    await api(`/rooms/${room.id}/messages`, { method: 'DELETE' });
    if (active?.id === room.id) await selectRoom(room);
  } catch (error) { $('chat-error').textContent = error.message; }
  finally { $('clear-chat').disabled = false; }
};

$('choose-avatar').onclick = () => {
  $('avatar-error').textContent = '';
  $('avatar-options').replaceChildren();
  for (const [key, icon] of Object.entries(avatars)) {
    const button = element('button', 'avatar-option', icon);
    button.type = 'button'; button.setAttribute('aria-label', key);
    button.setAttribute('aria-pressed', String(user.avatar === key));
    button.onclick = async () => {
      const buttons = [...$('avatar-options').children];
      buttons.forEach(item => item.disabled = true);
      try {
        await post('/avatar', { avatar: key });
        user.avatar = key;
        $('my-avatar').textContent = icon; $('selected-avatar-icon').textContent = icon;
        for (const row of $('messages').children) {
          if (Number(row.dataset.sender) === user.id) row.querySelector('.avatar').textContent = icon;
        }
        $('avatar-dialog').close();
      } catch (error) { $('avatar-error').textContent = error.message; }
      finally { buttons.forEach(item => item.disabled = false); }
    };
    $('avatar-options').append(button);
  }
  $('avatar-dialog').showModal();
};
$('close-avatar').onclick = () => $('avatar-dialog').close();

$('admin-reset').onclick = () => {
  $('admin-form').reset(); $('reset-status').textContent = '';
  $('admin-dialog').showModal();
};
$('close-admin').onclick = () => $('admin-dialog').close();
$('admin-dialog').addEventListener('close', () => $('admin-form').reset());
$('admin-form').onsubmit = async event => {
  event.preventDefault(); $('reset-submit').disabled = true; $('reset-status').textContent = '';
  try {
    await post('/admin/reset-password', {
      username: $('reset-username').value,
      new_password: $('reset-password').value,
      admin_password: $('admin-password').value
    });
    $('admin-form').reset();
    $('reset-status').textContent = 'Password reset. Share the new password privately with the user.';
  } catch (error) { $('reset-status').textContent = error.message; }
  finally { $('admin-password').value = ''; $('reset-submit').disabled = false; }
};
