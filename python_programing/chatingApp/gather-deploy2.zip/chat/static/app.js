const $ = id => document.getElementById(id);
const avatars = { fox: '🦊', cat: '🐱', dog: '🐶', panda: '🐼', koala: '🐨', lion: '🦁', rabbit: '🐰', bear: '🐻', owl: '🦉', penguin: '🐧', frog: '🐸', unicorn: '🦄' };
const avatarIcon = key => avatars[key] || avatars.fox;
const tabId = Array.from(crypto.getRandomValues(new Uint8Array(32)), byte => byte.toString(16).padStart(2, '0')).join('');
let browserToken = '';
let csrf = '', user = null, rooms = [], active = null, last = 0, first = 0;
let defaultRoomId = null;
let generation = 0, timer, dialogMode = 'room', polling = false, roomPoll = 0;
async function api(path, options = {}, retried = false) {
  const response = await fetch('/api' + path, { ...options, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf, 'X-Browser-Token': browserToken, 'X-Tab-ID': tabId }, credentials: 'same-origin' });
  const body = await response.json();
  if (response.status === 403 && body.code === 'csrf_expired' && !retried) {
    const previousUser = user?.id;
    const fresh = await api('/session');
    csrf = fresh.csrf;
    if (previousUser && fresh.user?.id !== previousUser) {
      user = null; generation++; clearTimeout(timer);
      $('app').hidden = true; $('auth').hidden = false;
      $('auth-error').textContent = 'Please sign in again. Your message draft is still here.';
      throw new Error('Please sign in again. Your message draft is still here.');
    }
    return api(path, options, true);
  }
  if (!response.ok) {
    if (response.status === 401 && user) { user = null; generation++; clearTimeout(timer); $('app').hidden = true; $('auth').hidden = false; $('username').value = ''; $('password').value = ''; browserToken = ''; }
    throw new Error(body.error || 'Something went wrong. Please try again.');
  }
  return body;
}
const post = (path, body) => api(path, { method: 'POST', body: JSON.stringify(body) });
function element(tag, className, text) { const node = document.createElement(tag); node.className = className; if (text !== undefined) node.textContent = text; return node; }
async function refreshRooms() {
  const result = await api('/rooms');
  rooms = result.rooms; defaultRoomId = result.default_room_id;
  $('room-list').replaceChildren(); $('direct-list').replaceChildren();
  rooms.forEach(room => {
    const button = element('button', active?.id === room.id ? 'active' : '');
    button.append(element('span', '', room.private ? '◉' : '#'), document.createTextNode(room.name));
    button.onclick = () => selectRoom(room);
    $(room.private ? 'direct-list' : 'room-list').append(button);
  });
}
function addMessages(messages, prepend = false) {
  const fragment = document.createDocumentFragment();
  messages.forEach(message => {
    if ($('messages').querySelector(`[data-id="${message.id}"]`)) return;
    const row = element('article', 'message-row' + (message.user_id === user.id ? ' mine' : ''));
    row.dataset.id = message.id; row.dataset.sender = message.user_id;
    const content = element('div', 'message-content');
    content.append(element('div', 'message-sender', message.user_id === user.id ? `You (${message.username})` : message.username));
    const meta = element('div', 'message-meta');
    const date = new Date(message.created_at);
    const time = element('time', '', date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    time.dateTime = message.created_at; time.title = date.toLocaleString();
    meta.append(time);
    if (message.user_id === user.id) {
      const receipt = element('span', 'message-receipt', '✓ Sent');
      receipt.setAttribute('aria-label', 'Sent; not seen yet');
      meta.append(receipt);
    }
    if (message.reply_to_id) {
      const quote = element('blockquote', 'reply-quote', message.reply_body === null ? 'Original message unavailable' : `${message.reply_username}: ${message.reply_body}`);
      quote.dataset.replyId = message.reply_to_id; content.append(quote);
    }
    const bubble = element('button', 'bubble message-tap', message.body);
    bubble.type = 'button'; bubble.title = 'Reply to this message';
    bubble.setAttribute('aria-label', `Reply to ${message.username}: ${message.body}`);
    bubble.onclick = () => { setReply(message); $('message').focus(); };
    const replyButton = element('button', 'reply-action', 'Reply');
    replyButton.type = 'button'; replyButton.onclick = bubble.onclick; meta.append(replyButton);
    content.append(bubble, meta);
    const avatar = element('span', 'avatar', avatarIcon(message.avatar));
    avatar.setAttribute('role', 'img');
    avatar.setAttribute('aria-label', message.username + ' avatar');
    row.append(avatar, content);
    fragment.append(row);
    last = Math.max(last, message.id); first = first ? Math.min(first, message.id) : message.id;
  });
  if (prepend) $('messages').prepend(fragment); else $('messages').append(fragment);
}
async function selectRoom(room) {
  setReply(null);
  active = room; const version = ++generation; last = 0; first = 0;
  closeSidebar(); $('messages').replaceChildren(); $('older').hidden = true;
  $('chat-error').textContent = ''; $('room-title').textContent = room.name;
  $('room-icon').textContent = room.private ? '◉' : '#';
  $('room-description').textContent = room.private ? 'A private conversation between the two of you.' : 'A public room. Everyone can read and join in.';
  updatePresenceHeader();
  $('welcome-title').textContent = room.private ? `Your conversation with ${room.name}` : `Welcome to #${room.name}`;
  for (const nav of [$('room-list'), $('direct-list')]) for (const button of nav.children) button.classList.toggle('active', button.textContent.slice(1) === room.name && (nav.id === 'direct-list') === Boolean(room.private));
  try {
    const result = await api(`/rooms/${room.id}/messages`);
    if (version !== generation) return;
    addMessages(result.messages); applyExpirations(result); $('older').hidden = result.messages.length < 100;
    $('message-scroll').scrollTop = $('message-scroll').scrollHeight;
    $('connection').textContent = '● Connected';
  } catch (error) { if (version === generation) $('chat-error').textContent = error.message; }
}
async function poll() {
  if (polling || !user) return;
  polling = true;
  try {
    if (!document.hidden && active) {
      await refreshPresence();
      const version = generation;
      const result = await api(`/rooms/${active.id}/messages?after=${last}`);
      if (version === generation) {
        const scroll = $('message-scroll'); const nearBottom = scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 120;
        addMessages(result.messages); applyExpirations(result); if (nearBottom) scroll.scrollTop = scroll.scrollHeight;
        $('connection').textContent = '● Connected';
      }
      if (++roomPoll % 5 === 0) await refreshRooms();
    }
  } catch (error) { $('connection').textContent = 'Reconnecting…'; }
  finally { polling = false; if (user) timer = setTimeout(poll, document.hidden ? 15000 : 3000); }
}
async function enterApp() {
  $('admin-personal').hidden = !user.is_admin;
  $('admin-remove').hidden = !user.is_admin;
  $('admin-create').hidden = !user.is_admin;
  $('admin-reset').hidden = !user.is_admin;
  await refreshPresence();
  $('sending-as').textContent = `Sending as ${user.username}`;
  $('auth').hidden = true; $('app').hidden = false; $('my-name').textContent = user.username; $('my-avatar').textContent = avatarIcon(user.avatar);
  $('selected-avatar-icon').textContent = avatarIcon(user.avatar);
  await refreshRooms(); await selectRoom(rooms.find(room => room.id === defaultRoomId) || rooms[0]); clearTimeout(timer); timer = setTimeout(poll, 3000);
}
$('auth-form').onsubmit = async event => {
  event.preventDefault(); $('auth-submit').disabled = true; $('auth-error').textContent = '';
  try { const result = await post('/login', { username: $('username').value, password: $('password').value }); csrf = result.csrf; browserToken = result.browser_token; user = result.user; $('password').value = ''; await enterApp(); }
  catch (error) { $(user ? 'chat-error' : 'auth-error').textContent = error.message; }
  finally { $('auth-submit').disabled = false; }
};
$('chat-logout').onclick = $('logout').onclick = async () => {
  $('chat-logout').disabled = true; $('logout').disabled = true;
  try { await post('/logout', {}); user = null; generation++; clearTimeout(timer); $('app').hidden = true; $('auth').hidden = false; $('username').value = ''; $('password').value = ''; browserToken = ''; csrf = (await api('/session')).csrf; }
  catch (error) { $('chat-error').textContent = error.message; }
  finally { $('chat-logout').disabled = false; $('logout').disabled = false; }
};
$('composer').onsubmit = async event => {
  event.preventDefault(); const text = $('message').value.trim(); if (!text || !active || $('send').disabled) return;
  const reply = replying; const roomId = active.id; const draft = $('message').value; $('send').disabled = true; $('chat-error').textContent = '';
  try { await post(`/rooms/${roomId}/messages`, { body: text, reply_to_id: reply?.id || null }); if (active?.id === roomId && replying === reply) setReply(null); if (active?.id === roomId && $('message').value === draft) { $('message').value = ''; $('character-count').textContent = '0 / 2000'; } clearTimeout(timer); await poll(); }
  catch (error) { $('chat-error').textContent = error.message; }
  finally { $('send').disabled = false; $('message').focus(); }
};
$('message').onkeydown = event => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); $('composer').requestSubmit(); } };
$('message').oninput = () => $('character-count').textContent = `${$('message').value.length} / 2000`;
$('older').onclick = async () => {
  const version = generation; $('older').disabled = true;
  try { const result = await api(`/rooms/${active.id}/messages?before=${first}`); if (version !== generation) return; const scroll = $('message-scroll'); const oldHeight = scroll.scrollHeight; addMessages(result.messages, true); applyExpirations(result); scroll.scrollTop += scroll.scrollHeight - oldHeight; $('older').hidden = result.messages.length < 100; }
  catch (error) { $('chat-error').textContent = error.message; } finally { $('older').disabled = false; }
};
function openDialog(mode) {
  dialogMode = mode; $('dialog-title').textContent = mode === 'room' ? 'Create a room' : 'Start a conversation';
  $('dialog-description').textContent = mode === 'room' ? 'Public rooms are visible to everyone. Give yours a name.' : 'Enter the exact username of someone with a chat account.';
  $('dialog-label').textContent = mode === 'room' ? 'Room name' : 'Username'; $('dialog-input').value = ''; $('dialog-error').textContent = ''; $('create-dialog').showModal();
}
$('new-room').onclick = () => openDialog('room'); $('new-direct').onclick = () => openDialog('direct');
$('close-dialog').onclick = () => $('create-dialog').close();
$('create-form').onsubmit = async event => {
  event.preventDefault(); const button = event.submitter; button.disabled = true;
  try { const value = $('dialog-input').value; const result = await post(dialogMode === 'room' ? '/rooms' : '/direct', dialogMode === 'room' ? { name: value } : { username: value }); await refreshRooms(); $('create-dialog').close(); await selectRoom(rooms.find(room => room.id === result.id)); }
  catch (error) { $('dialog-error').textContent = error.message; } finally { button.disabled = false; }
};
$('menu').onclick = () => {
  const open = $('app').classList.toggle('show-sidebar');
  $('sidebar-backdrop').hidden = !open; $('menu').setAttribute('aria-expanded', String(open));
};
function closeSidebar() {
  $('app').classList.remove('show-sidebar'); $('sidebar-backdrop').hidden = true;
  $('menu').setAttribute('aria-expanded', 'false');
}
$('sidebar-backdrop').onclick = closeSidebar;
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeSidebar(); });
async function boot() { try { const result = await api('/session'); csrf = result.csrf; user = result.user; if (user) await enterApp(); } catch (error) { $(user ? 'chat-error' : 'auth-error').textContent = 'Unable to connect. Refresh to retry. ' + error.message; } }
boot();

function applyExpirations(result) {
  for (const id of result.unavailable_replies || []) {
    const quote = $('messages').querySelector(`[data-id="${id}"] .reply-quote`);
    if (quote) quote.textContent = 'Original message unavailable';
  }
  for (const expiry of result.expirations || []) {
    const row = $('messages').querySelector(`[data-id="${expiry.id}"]`);
    if (row) {
      row.dataset.expires = Date.now() + Math.max(0, expiry.expires_at - result.server_time) * 1000;
      const receipt = row.querySelector('.message-receipt');
      if (receipt) {
        receipt.textContent = '✓✓ Seen';
        receipt.classList.add('is-seen');
        receipt.setAttribute('aria-label', 'Seen by another person');
        receipt.title = 'Seen by another person. Deletes 5 minutes after first seen.';
      }
    }
  }
}
let reading = false;
setInterval(async () => {
  for (const row of $('messages').children) {
    if (row.dataset.expires && Number(row.dataset.expires) <= Date.now()) removeMessage(row);
  }
  if (!user || !active || document.hidden || !document.hasFocus() || reading) return;
  const bounds = $('message-scroll').getBoundingClientRect();
  const visible = [...$('messages').children].filter(row => {
    const rect = row.getBoundingClientRect();
    return Number(row.dataset.sender) !== user.id && !row.dataset.seen && rect.bottom > bounds.top && rect.top < bounds.bottom;
  }).slice(0, 100);
  if (!visible.length) return;
  reading = true;
  try {
    await post(`/rooms/${active.id}/seen`, { ids: visible.map(row => Number(row.dataset.id)) });
    visible.forEach(row => { row.dataset.seen = '1'; if (!row.dataset.expires) row.dataset.expires = Date.now() + 300000; });
  } catch (_) { /* Retry visible receipts on the next tick. */ }
  finally { reading = false; }
}, 1000);
window.addEventListener('pageshow', event => {
  $('username').value = ''; $('password').value = '';
  if (event.persisted) location.reload();
});

let syncing = false;
setInterval(async () => {
  if (!user || !active || document.hidden || syncing) return;
  syncing = true;
  const version = generation, roomId = active.id;
  const rows = [...$('messages').children];
  try {
    for (let i = 0; i < rows.length; i += 100) {
      const batch = rows.slice(i, i + 100);
      const result = await post(`/rooms/${roomId}/state`, { ids: batch.map(row => Number(row.dataset.id)) });
      if (version !== generation) return;
      batch.forEach(row => { if (!result.alive.includes(Number(row.dataset.id))) removeMessage(row); });
      applyExpirations(result);
    }
  } catch (_) { /* Reconcile again when the connection returns. */ }
  finally { syncing = false; }
}, 3000);

$('clear-chat').onclick = async () => {
  if (!active || !user) return;
  const room = active;
  if (!window.confirm(`Clear all messages in ${room.name}? This permanently deletes the chat history for everyone in this conversation and cannot be undone.`)) return;
  $('clear-chat').disabled = true;
  $('chat-error').textContent = '';
  try {
    await api(`/rooms/${room.id}/messages`, { method: 'DELETE' });
    if (active?.id === room.id) await selectRoom(room);
  } catch (error) { $('chat-error').textContent = error.message; }
  finally { $('clear-chat').disabled = false; }
};

$('choose-avatar').onclick = () => {
  $('avatar-error').textContent = '';
  $('avatar-options').replaceChildren();
  for (const [key, icon] of Object.entries(avatars)) {
    const button = element('button', 'avatar-option', icon);
    button.type = 'button'; button.setAttribute('aria-label', key);
    button.setAttribute('aria-pressed', String(user.avatar === key));
    button.onclick = async () => {
      const buttons = [...$('avatar-options').children];
      buttons.forEach(item => item.disabled = true);
      try {
        await post('/avatar', { avatar: key });
        user.avatar = key;
        $('my-avatar').textContent = icon; $('selected-avatar-icon').textContent = icon;
        for (const row of $('messages').children) {
          if (Number(row.dataset.sender) === user.id) row.querySelector('.avatar').textContent = icon;
        }
        $('avatar-dialog').close();
      } catch (error) { $('avatar-error').textContent = error.message; }
      finally { buttons.forEach(item => item.disabled = false); }
    };
    $('avatar-options').append(button);
  }
  $('avatar-dialog').showModal();
};
$('close-avatar').onclick = () => $('avatar-dialog').close();

$('admin-reset').onclick = () => {
  $('admin-form').reset(); $('reset-status').textContent = '';
  $('admin-dialog').showModal();
};
$('close-admin').onclick = () => $('admin-dialog').close();
$('admin-dialog').addEventListener('close', () => $('admin-form').reset());
$('admin-form').onsubmit = async event => {
  event.preventDefault(); $('reset-submit').disabled = true; $('reset-status').textContent = '';
  try {
    await post('/admin/reset-password', {
      username: $('reset-username').value,
      new_password: $('reset-password').value,
      admin_password: $('admin-password').value
    });
    $('admin-form').reset();
    $('reset-status').textContent = 'Password reset. Share the new password privately with the user.';
  } catch (error) { $('reset-status').textContent = error.message; }
  finally { $('admin-password').value = ''; $('reset-submit').disabled = false; }
};

let replying = null, people = [];
function setReply(message) {
  replying = message; $('reply-preview').hidden = !message;
  $('reply-text').textContent = message ? `Replying to ${message.username}: ${message.body}` : '';
}
$('cancel-reply').onclick = () => setReply(null);
function removeMessage(row) {
  const id = Number(row.dataset.id);
  if (replying?.id === id) setReply(null);
  for (const quote of document.querySelectorAll(`[data-reply-id="${id}"]`)) quote.textContent = 'Original message unavailable';
  row.remove();
}
function statusText(person) {
  return person.online ? 'Online' : person.last_seen ? `Last seen ${new Date(person.last_seen * 1000).toLocaleString()}` : 'Offline';
}
function updatePresenceHeader() {
  if (!$('header-presence')) {
    const status = element('span', '', '');
    status.id = 'header-presence'; status.setAttribute('role', 'status');
    $('connection').before(status);
  }
  if (!active) return;
  if (!active.private) {
    const others = people.filter(person => person.id !== user?.id);
    $('header-presence').replaceChildren(...others.map(person => element('span', person.online ? 'person-online' : '', `${person.username}: ${statusText(person)}`)));
    if (!others.length) $('header-presence').textContent = 'No other chat accounts';
    $('room-description').textContent = 'A public room. Everyone can read and join in.';
    return;
  }
  const person = people.find(person => person.username === active.name);
  $('header-presence').textContent = person ? `${person.username}: ${statusText(person)}` : '';
  $('room-description').textContent = 'A private conversation between the two of you.';
}
async function refreshPresence() {
  const result = await post('/presence', {});
  if (!user) return;
  people = result.users; $('people-list').replaceChildren();
  for (const person of people.filter(person => person.id !== user.id)) {
    const row = element('div', 'person');
    row.append(element('strong', '', person.username), element('small', person.online ? 'person-online' : '', statusText(person)));
    $('people-list').append(row);
  }
  updatePresenceHeader();
}
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && user) { clearTimeout(timer); poll(); }
});
$('admin-create').onclick = () => {
  $('account-form').reset(); $('account-status').textContent = ''; $('account-dialog').showModal();
};
$('close-account').onclick = () => $('account-dialog').close();
$('account-dialog').addEventListener('close', () => $('account-form').reset());
$('account-form').onsubmit = async event => {
  event.preventDefault(); $('account-submit').disabled = true; $('account-status').textContent = '';
  try {
    const result = await post('/admin/users', { username: $('account-username').value, password: $('account-password').value });
    $('account-form').reset(); $('account-status').textContent = `Account created for ${result.username}. Share their credentials privately.`;
    await refreshPresence();
  } catch (error) { $('account-status').textContent = error.message; }
  finally { $('account-submit').disabled = false; }
};

$('admin-remove').onclick = async () => {
  $('remove-form').reset(); $('remove-status').textContent = '';
  $('remove-user').replaceChildren(); $('remove-submit').disabled = true;
  $('remove-dialog').showModal();
  try {
    const result = await api('/admin/users');
    for (const account of result.users) {
      const option = element('option', '', account.username); option.value = account.id;
      $('remove-user').append(option);
    }
    $('remove-submit').disabled = !result.users.length;
    if (!result.users.length) $('remove-status').textContent = 'No users available to remove.';
  } catch (error) { $('remove-status').textContent = error.message; }
};
$('close-remove').onclick = () => $('remove-dialog').close();
$('remove-dialog').addEventListener('close', () => $('remove-form').reset());
$('remove-form').onsubmit = async event => {
  event.preventDefault();
  const selected = $('remove-user').selectedOptions[0];
  if (!selected || !confirm(`Remove ${selected.textContent}? They will lose access to all chats.`)) return;
  $('remove-submit').disabled = true;
  try {
    await api(`/admin/users/${selected.value}`, { method: 'DELETE', body: JSON.stringify({ admin_password: $('remove-password').value }) });
    selected.remove(); $('remove-status').textContent = 'User removed. Their existing sessions can no longer access chats.';
    await refreshPresence();
  } catch (error) { $('remove-status').textContent = error.message; }
  finally { $('remove-password').value = ''; $('remove-submit').disabled = !$('remove-user').options.length; }
};

$('admin-personal').onclick = async () => {
  $('personal-status').textContent = ''; $('personal-submit').disabled = true;
  $('personal-first').replaceChildren(); $('personal-second').replaceChildren();
  $('personal-dialog').showModal();
  try {
    const result = await api('/admin/users');
    for (const account of result.users) {
      for (const id of ['personal-first', 'personal-second']) {
        const option = element('option', '', account.username); option.value = account.id; $(id).append(option);
      }
    }
    if (result.users.length >= 2) { $('personal-second').selectedIndex = 1; $('personal-submit').disabled = false; }
    else $('personal-status').textContent = 'Create at least two regular user accounts first.';
  } catch (error) { $('personal-status').textContent = error.message; }
};
$('close-personal').onclick = () => $('personal-dialog').close();
$('personal-form').onsubmit = async event => {
  event.preventDefault(); $('personal-submit').disabled = true;
  try {
    await post('/admin/personal-chat', { user_ids: [Number($('personal-first').value), Number($('personal-second').value)] });
    $('personal-status').textContent = 'Personal chat ready for both users. It will open by default at their next sign-in.';
  } catch (error) { $('personal-status').textContent = error.message; }
  finally { $('personal-submit').disabled = false; }
};

const mobileLayout = matchMedia('(max-width: 760px)');
const mobileActionIds = ['choose-avatar', 'admin-personal', 'admin-create', 'admin-remove', 'admin-reset', 'clear-chat'];
const actionPositions = mobileActionIds.map(id => {
  const node = $(id), anchor = document.createComment(id);
  node.before(anchor);
  node.addEventListener('click', () => $('mobile-actions-dialog').close());
  return { node, anchor };
});
function applyMobileLayout() {
  $('mobile-actions-dialog').close(); closeSidebar();
  for (const { node, anchor } of actionPositions) {
    if (mobileLayout.matches) $('mobile-actions-list').append(node);
    else anchor.after(node);
  }
}
mobileLayout.addEventListener('change', applyMobileLayout);
applyMobileLayout();
$('mobile-actions').onclick = () => $('mobile-actions-dialog').showModal();
$('close-mobile-actions').onclick = () => $('mobile-actions-dialog').close();
$('mobile-signout').onclick = () => { $('mobile-actions-dialog').close(); $('chat-logout').click(); };
