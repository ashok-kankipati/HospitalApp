# Update an existing PythonAnywhere deployment

These commands assume your existing project is ~/chatingApp and virtualenv is gather-env. If your Web tab lists different locations, use those existing locations instead. Keep the existing instance directory; it contains your accounts, database, and signing key.

1. Upload gather-pythonanywhere-latest.zip using the Files tab into your home directory (/home/YOUR_USERNAME).
2. Open a Bash console, activate your existing environment, and back up before updating:

```bash
workon gather-env
cd ~/chatingApp
python -c "import sqlite3, pathlib, datetime, shutil; folder=pathlib.Path.home()/('gather-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')); folder.mkdir(); source=sqlite3.connect('file:instance/chat.sqlite3?mode=ro', uri=True); target=sqlite3.connect(str(folder/'chat.sqlite3')); source.backup(target); target.close(); source.close(); key=pathlib.Path('instance/secret.key'); shutil.copy2(key,folder/'secret.key') if key.exists() else None; print('Backup:',folder)"
unzip -o ~/gather-pythonanywhere-latest.zip -d ~/chatingApp
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

If the database backup reports a missing file, check your existing DATABASE location before proceeding. Do not create a new empty project directory for an existing installation.

3. In Web, confirm the Source code and Working directory both point to /home/YOUR_USERNAME/chatingApp. Keep your existing virtualenv, whose Python version must match the web app.
4. In the WSGI configuration file linked from Web, use the following (replace YOUR_USERNAME):

```python
import sys
project = '/home/YOUR_USERNAME/chatingApp'
if project not in sys.path:
    sys.path.insert(0, project)
from wsgi import application
```

Keep any existing custom SECRET_KEY or database configuration you previously used. The bundled wsgi.py enables secure cookies; use HTTPS and enable Force HTTPS in Web.

5. Confirm the static mapping: URL /static/ -> directory /home/YOUR_USERNAME/chatingApp/chat/static. Never map instance as a static directory.
6. Click Reload in the Web tab. Do not run python app.py or flask run to serve the hosted website.
7. Open your HTTPS site. Hard-refresh desktop pages (Ctrl+Shift+R). On mobile, close the old chat tab and reopen the site; if old styling persists, clear that site's cached files. Sign in again after this update.
8. Test two users in separate tabs, sending/replying, header online/last-seen status, and logout in one tab without logging out the other.

Database changes are applied automatically when the web app loads. Existing accounts and messages are retained, subject to the existing message-expiry policy. This ZIP excludes local databases, keys, logs, virtualenvs, and caches.

If you already have an administrator, use that account. Only if you need a new dedicated administrator, run in the activated environment:

```bash
cd ~/chatingApp
flask --app app create-admin
```

Then sign in as the administrator and use Create account. Public sign-up is disabled. There is no default admin password.

If Reload fails, read the error log linked in Web. Check the project path, matching virtualenv, and that chat/tab_sessions.py was extracted.

Official references:
- https://help.pythonanywhere.com/pages/Flask
- https://help.pythonanywhere.com/pages/StaticFiles
- https://help.pythonanywhere.com/pages/ReloadWebApp/
